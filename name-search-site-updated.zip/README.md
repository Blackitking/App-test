# Name Search Site

Public name search with no login. Admin changes require the server-side ADMIN_CODE.

## Environment variables
- `DATABASE_URL` = PostgreSQL connection string
- `ADMIN_CODE` = your secret admin code
- `PORT` = optional; Render supplies this automatically

## Deploy
1. Upload this folder to GitHub.
2. Create a PostgreSQL database and copy its connection string.
3. Create a Node Web Service on your hosting provider.
4. Build command: `npm install`
5. Start command: `npm start`
6. Set `DATABASE_URL` and `ADMIN_CODE` as environment variables.

The public page only exposes names. Do not place ID numbers, phone numbers, health data, vaccination data, or other sensitive personal data in the public database.
