import express from "express";
import pg from "pg";

const { Pool } = pg;
const app = express();

app.use(express.json({ limit: "100kb" }));
app.use(express.static("public"));

const PORT = process.env.PORT || 3000;
const ADMIN_CODE = process.env.ADMIN_CODE;

if (!ADMIN_CODE) {
  console.error("ADMIN_CODE environment variable is required.");
  process.exit(1);
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_URL ? { rejectUnauthorized: false } : false
});

async function initDb() {
  if (!process.env.DATABASE_URL) {
    throw new Error("DATABASE_URL environment variable is required.");
  }

  await pool.query(`
    CREATE TABLE IF NOT EXISTS people (
      id SERIAL PRIMARY KEY,
      name TEXT NOT NULL CHECK (length(trim(name)) > 0),
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
}

function adminOk(req) {
  return req.headers["x-admin-code"] === ADMIN_CODE;
}

app.get("/api/search", async (req, res) => {
  try {
    const q = String(req.query.q || "").trim();
    const words = q.split(/\s+/).filter(Boolean);

    if (!words.length) {
      return res.json([]);
    }

    const conditions = [];
    const values = [];

    for (const word of words.slice(0, 5)) {
      values.push(`%${word}%`);
      conditions.push(`name ILIKE $${values.length}`);
    }

    const { rows } = await pool.query(
      `SELECT id, name
       FROM people
       WHERE ${conditions.join(" AND ")}
       ORDER BY name
       LIMIT 100`,
      values
    );

    res.json(rows);
  } catch {
    res.status(500).json({ error: "هەڵەی سێرڤەر" });
  }
});

app.post("/api/admin/people", async (req, res) => {
  if (!adminOk(req)) return res.status(401).json({ error: "کۆدی Admin هەڵەیە" });

  const name = String(req.body?.name || "").trim();
  if (!name) return res.status(400).json({ error: "ناو پێویستە" });

  try {
    const { rows } = await pool.query(
      "INSERT INTO people (name) VALUES ($1) RETURNING id, name",
      [name]
    );
    res.json(rows[0]);
  } catch {
    res.status(500).json({ error: "هەڵەی سێرڤەر" });
  }
});

app.put("/api/admin/people/:id", async (req, res) => {
  if (!adminOk(req)) return res.status(401).json({ error: "کۆدی Admin هەڵەیە" });

  const name = String(req.body?.name || "").trim();
  if (!name) return res.status(400).json({ error: "ناو پێویستە" });

  try {
    const { rows } = await pool.query(
      "UPDATE people SET name = $1 WHERE id = $2 RETURNING id, name",
      [name, req.params.id]
    );

    if (!rows.length) return res.status(404).json({ error: "نەدۆزرایەوە" });
    res.json(rows[0]);
  } catch {
    res.status(500).json({ error: "هەڵەی سێرڤەر" });
  }
});

app.delete("/api/admin/people/:id", async (req, res) => {
  if (!adminOk(req)) return res.status(401).json({ error: "کۆدی Admin هەڵەیە" });

  try {
    await pool.query("DELETE FROM people WHERE id = $1", [req.params.id]);
    res.json({ ok: true });
  } catch {
    res.status(500).json({ error: "هەڵەی سێرڤەر" });
  }
});

initDb()
  .then(() => {
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  })
  .catch((err) => {
    console.error(err);
    process.exit(1);
  });
